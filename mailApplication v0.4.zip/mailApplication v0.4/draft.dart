class draft {
  int draftID;
  String? sendTo;
  String? carbonCopy;
  String? blindCopy;
  String? sender;
  String? title;
  String? content;
  String? chosenFile;
  int? replyTo;
  String? forwardTo;
  int favorited;

  draft(
      this.draftID,
      this.sendTo,
      this.carbonCopy,
      this.blindCopy,
      this.sender,
      this.title,
      this.content,
      this.chosenFile,
      this.replyTo,
      this.forwardTo,
      this.favorited);

  Map<String, dynamic> toMap() {
    return {
      'sendTo': sendTo,
      'sender': sender,
      'carbonCopy': carbonCopy,
      'blindCopy': blindCopy,
      'title': title,
      'content': content,
      'chosenFile': chosenFile,
      'replyTo': replyTo,
      'forwarded': forwardTo,
      'favoriteTo': favorited
    };
  }

  static draft fromMap(Map<String, dynamic> map) {
    return draft(
        map['mailID'],
        map['sendTo'],
        map['carbonCopy'],
        map['blindCopy'],
        map['sender'],
        map['title'],
        map['content'],
        map['chosenFile'],
        map['replyTo'],
        map['forwardTo'],
        map['favorited']);
  }
}
