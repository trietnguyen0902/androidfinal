import 'package:flutter_application_finals/blocked.dart';
import 'package:flutter_application_finals/email.dart';
import 'package:flutter_application_finals/user.dart';
import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';

class DatabaseService {
  static DatabaseService instance = DatabaseService._init();
  DatabaseService._init();

  factory DatabaseService() {
    return instance;
  }

  Database? _db;
  Future<Database> get database async {
    if (_db != null) {
      return _db!;
    }

    String appDB = 'app.db';
    String dbPath = join(await getDatabasesPath(), appDB);
    _db = await openDatabase(dbPath, version: 1, onCreate: (db, version) {
      db.execute('''CREATE TABLE USERS{
        userID INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT NOT NULL,
        userPhone INTEGER NOT NULL,
        userPassword TEXT NOT NULL,
      }

      CREATE TABLE EMAILS{
        mailID INTEGER PRIMARY KEY AUTOINCREMENT,
        sendTo TEXT NOT NULL,
        carbonCopy TEXT NOT NULL,
        blindCopy TEXT NOT NULL,
        sender TEXT NOT NULL,
        title TEXT NOT NULL,
        content TEXT,
        chosenFile TEXT,
        replyTo INTEGER,
        forwardTo TEXT,
        favorited INTEGER,
      } 
      
      CREATE TABLE BLOCKLIST{
        blockID INTEGER PRIMARY KEY AUTOINCREMENT,
        blocker TEXT NOT NULL,
        blocked TEXT NOT NULL,
      }''');
    });

    return _db!;
  }

  Future<List<eMail>> showEmail(String user) async {
    var db = await database;
    var data = await db.rawQuery(
        'SELECT * FROM EMAILS WHERE sendto = ? OR carbonCopy = ? OR blindCopy = ?',
        [user, user, user]);
    return data.map((e) => eMail.fromMap(e)).toList();
  }

  Future<List<eMail>> readEmail(int id, String user) async {
    var db = await database;
    var data = await db.rawQuery(
        'SELECT * FROM EMAILS WHERE mailID = ? AND sendto = ?', [id, user]);
    return data.map((e) => eMail.fromMap(e)).toList();
  }

  Future<List<eMail>> showFavoritedMail(String user) async {
    var db = await database;
    var data = await db.rawQuery(
        'SELECT * FROM EMAILS WHERE sendto = ? AND favorited = 1', [user]);
    return data.map((e) => eMail.fromMap(e)).toList();
  }

  Future<List<eMail>> showSentMail(String user) async {
    var db = await database;
    var data =
        await db.rawQuery('SELECT * FROM EMAILS WHERE sender = ?', [user]);
    return data.map((e) => eMail.fromMap(e)).toList();
  }

  Future<List<Blocked>> showBlockList(String user) async {
    var db = await database;
    var data =
        await db.rawQuery('SELECT * FROM BLOCKLIST WHERE blocker = ?', [user]);
    return data.map((e) => Blocked.fromMap(e)).toList();
  }

  Future<int> insertEMail(
    String sendTo,
    String sender,
    String carbonCopy,
    String blindCopy,
    String title,
    String content,
    String chosenFile,
    int? replyTo,
    String? forwardTo,
  ) async {
    var db = await database;
    return await db.insert(
        'EMAILS',
        eMail(0, sendTo, sender, carbonCopy, blindCopy, title, content,
                chosenFile, replyTo, forwardTo, 0)
            .toMap());
  }

  Future<int> insertReply(
    String sendTo,
    String sender,
    String carbonCopy,
    String blindCopy,
    String title,
    String content,
    String chosenFile,
    int? replyTo,
    String? forwardTo,
  ) async {
    var db = await database;
    return await db.insert(
        'EMAILS',
        eMail(0, sendTo, sender, carbonCopy, blindCopy, title, content,
                chosenFile, replyTo, forwardTo, 0)
            .toMap());
  }

  Future<int> insertUser(
      String username, int userPhone, String userPassword) async {
    var db = await database;
    return await db.insert(
        'USERS', User(0, username, userPhone, userPassword).toMap());
  }

  Future<int> insertBlock(String blocker, String blocked) async {
    var db = await database;
    return await db.insert('BLOCKLIST', Blocked(0, blocker, blocked).toMap());
  }

  Future<int> favoriteMail(
    int id,
  ) async {
    var db = await database;
    return await db
        .rawUpdate('UPDATE EMAILS SET favorited = 1 WHERE mailID =?', [id]);
  }

  Future<int> unFavoriteMail(
    int id,
  ) async {
    var db = await database;
    return await db
        .rawUpdate('UPDATE EMAILS SET favorited = 0 WHERE mailID =?', [id]);
  }

  Future<int> fowardToAnother(int id, String newSendTo) async {
    var db = await database;
    return await db.rawUpdate(
        'UPDATE EMAILS SET sendTo = ? WHERE mailID =?', [newSendTo, id]);
  }

  Future<int> deleteMail(int id) async {
    var db = await database;
    return await db.rawDelete('DELETE * FROM EMAILS WHERE mailID = ?', [id]);
  }

  Future<int> unblockUser(String blocker, String blocked) async {
    var db = await database;
    return await db.rawDelete(
        'DELETE FROM BLOCKED WHERE blocker = ? AND blocked = ?',
        [blocker, blocked]);
  }
}
