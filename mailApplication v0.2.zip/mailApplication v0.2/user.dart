class User {
  int userID;
  String username;
  int userPhone;
  String userPassword;

  User(
    this.userID,
    this.username,
    this.userPhone,
    this.userPassword,
  );

  Map<String, dynamic> toMap() {
    return {
      'username': username,
      'userPhone': userPhone,
      'userPassword': userPassword,
    };
  }

  static User fromMap(Map<String, dynamic> map) {
    return User(
        map['userID'], map['userPhone'], map['username'], map['userPassword']);
  }
}
