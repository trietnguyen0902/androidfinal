import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter_application_finals/blocked.dart';
import 'package:flutter_application_finals/database_service.dart';
import 'package:flutter_application_finals/draft.dart';
import 'package:flutter_application_finals/email.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized;
  runApp(
      const MaterialApp(debugShowCheckedModeBanner: false, home: HomePage()));
}

//Homepage
class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  var db = DatabaseService();

  //TODO: change this when finifh implementing login system!
  late String username = "adminNNT@mail.com";

  List<eMail> _foundEntries = [];

  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      drawer: Drawer(
          child: ListView(
        children: [
          DrawerHeader(
              child: Column(
            children: [
              //TODO: Remove const when implement user profile picture
              const CircleAvatar(
                radius: 15,
                backgroundColor: Colors.yellow,
              ),
              Text(username)
            ],
          )),
          ListTile(
            leading: const Icon(Icons.star),
            title: const Text('Starred mail'),
            onTap: () {
              Navigator.pop(context);
              Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (ctx) => FavoritedMail(
                            username: username,
                          )));
            },
          ),
          ListTile(
            leading: const Icon(Icons.send),
            title: const Text('Sent mail'),
            onTap: () {
              Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (ctx) => SentMail(
                            username: username,
                          )));
            },
          ),
          ListTile(
              leading: const Icon(Icons.drafts),
              title: const Text('Drafts'),
              onTap: () {
                Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (ctx) => Drafts(username: username)));
              }),
          ListTile(
              leading: const Icon(Icons.delete_rounded),
              title: const Text('Trash'),
              onTap: () {
                Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (ctx) => Trash(username: username)));
              }),
          ListTile(
            leading: const Icon(Icons.block),
            title: const Text('Blocked list'),
            onTap: () {
              Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (ctx) => Blocklist(username: username)));
            },
          ),
          ListTile(
            leading: const Icon(Icons.settings),
            title: const Text('Settings'),
            onTap: () {
              Navigator.push(context,
                  MaterialPageRoute(builder: (ctx) => const Settings()));
            },
          )
        ],
      )),
      appBar: AppBar(
        title: const Text('Homepage'),
        backgroundColor: Colors.redAccent,
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            TextField(
              scrollPadding: const EdgeInsets.all(24),
              onChanged: (value) => _runFilter(value),
              decoration: const InputDecoration(
                  hintText: "Search", suffixIcon: Icon(Icons.search)),
            ),
            FutureBuilder(
              future: db.showEmail(username),
              builder: (context, snapshot) {
                if (!snapshot.hasData) {
                  return const Center(
                    child: CircularProgressIndicator(),
                  );
                }
                List<eMail> allMail = snapshot.data!;
                setState(() {
                  _foundEntries = allMail;
                });
                return _foundEntries.isEmpty
                    ? const Center(
                        child: Text('No mail'),
                      )
                    : ListView.separated(
                        itemBuilder: (ctx, idx) =>
                            _buildMail(_foundEntries[idx]),
                        separatorBuilder: (ctx, idx) => const Divider(),
                        itemCount: _foundEntries.length,
                      );
              },
            ),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () {
          Navigator.push(
              context, MaterialPageRoute(builder: (ctx) => const WriteMail()));
        },
        label: const Text('Write Email'),
        icon: const Icon(Icons.add),
      ),
    );
  }

  Widget _buildMail(
    eMail mail,
  ) {
    return ListTile(
      title: Text(mail.sender),
      subtitle: Text(mail.title),
      onTap: () {
        Navigator.push(
            context,
            MaterialPageRoute(
                builder: (ctx) => ReadMail(
                      mailID: mail.mailID,
                      sendTo: mail.sendTo,
                      carbonCopy: mail.carbonCopy,
                      blindCopy: mail.blindCopy,
                      sender: mail.sender,
                      title: mail.title,
                      content: mail.content,
                      chosenFile: mail.chosenFile,
                      replyTo: mail.replyTo,
                      fowardTo: mail.forwardTo,
                      favorited: mail.favorited,
                    )));
      },
    );
  }

  void _runFilter(String keyword) {
    List<eMail> searchResults = [];
    if (keyword.isEmpty) {
      searchResults = _foundEntries;
    } else {
      searchResults = _foundEntries
          .where((eMail) =>
              eMail.title.toLowerCase().contains(keyword.toLowerCase()))
          .toList();
      searchResults += _foundEntries
          .where((eMail) =>
              eMail.content.toLowerCase().contains(keyword.toLowerCase()))
          .toList();
      searchResults += _foundEntries
          .where((eMail) =>
              eMail.sender.toLowerCase().contains(keyword.toLowerCase()))
          .toList();
    }

    setState(() {
      _foundEntries = searchResults;
    });
  }
}

//Page for displaying favorited emails
class FavoritedMail extends StatefulWidget {
  const FavoritedMail({super.key, required String username});

  @override
  State<FavoritedMail> createState() => _FavoriteMailState();
}

class _FavoriteMailState extends State<FavoritedMail> {
  late String username;

  var db = DatabaseService();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Favorited'),
        backgroundColor: Colors.redAccent,
      ),
      body: FutureBuilder(
        future: db.showFavoritedMail(username),
        builder: (context, snapshot) {
          if (!snapshot.hasData) {
            return const Center(
              child: CircularProgressIndicator(),
            );
          }
          List<eMail> allMail = snapshot.data!;
          return allMail.isEmpty
              ? const Center(
                  child: Text('No mail'),
                )
              : ListView.separated(
                  itemBuilder: (ctx, idx) => _buildFavoriteMail(allMail[idx]),
                  separatorBuilder: (ctx, idx) => const Divider(),
                  itemCount: allMail.length,
                );
        },
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () {
          Navigator.push(
              context, MaterialPageRoute(builder: (ctx) => const WriteMail()));
        },
        label: const Text('Write Email'),
        icon: const Icon(Icons.add),
      ),
    );
  }

  Widget _buildFavoriteMail(
    eMail mail,
  ) {
    return ListTile(
      title: Text(mail.sender),
      subtitle: Text(mail.title),
      onTap: () {
        Navigator.push(
            context,
            MaterialPageRoute(
                builder: (ctx) => ReadMail(
                      mailID: mail.mailID,
                      sendTo: mail.sendTo,
                      carbonCopy: mail.carbonCopy,
                      blindCopy: mail.blindCopy,
                      sender: mail.sender,
                      title: mail.title,
                      content: mail.content,
                      chosenFile: mail.chosenFile,
                      replyTo: mail.replyTo,
                      fowardTo: mail.forwardTo,
                      favorited: mail.favorited,
                    )));
      },
    );
  }
}

//Page for displaying sent emails
class SentMail extends StatefulWidget {
  const SentMail({super.key, required String username});

  @override
  State<SentMail> createState() => _SentMailState();
}

class _SentMailState extends State<SentMail> {
  late String username;

  var db = DatabaseService();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Sent mail'),
        backgroundColor: Colors.redAccent,
      ),
      body: FutureBuilder(
        future: db.showSentMail(username),
        builder: (context, snapshot) {
          if (!snapshot.hasData) {
            return const Center(
              child: CircularProgressIndicator(),
            );
          }
          List<eMail> allMail = snapshot.data!;
          return allMail.isEmpty
              ? const Center(
                  child: Text('No mail'),
                )
              : ListView.separated(
                  itemBuilder: (ctx, idx) => _buildSenteMail(allMail[idx]),
                  separatorBuilder: (ctx, idx) => const Divider(),
                  itemCount: allMail.length,
                );
        },
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () {
          Navigator.push(
              context, MaterialPageRoute(builder: (ctx) => const WriteMail()));
        },
        label: const Text('Write Email'),
        icon: const Icon(Icons.add),
      ),
    );
  }

  Widget _buildSenteMail(
    eMail mail,
  ) {
    return ListTile(
      title: Text(mail.sender),
      subtitle: Text(mail.title),
      onTap: () {
        Navigator.push(
            context,
            MaterialPageRoute(
                builder: (ctx) => ReadMail(
                      mailID: mail.mailID,
                      sendTo: mail.sendTo,
                      carbonCopy: mail.carbonCopy,
                      blindCopy: mail.blindCopy,
                      sender: mail.sender,
                      title: mail.title,
                      content: mail.content,
                      chosenFile: mail.chosenFile,
                      replyTo: mail.replyTo,
                      fowardTo: mail.forwardTo,
                      favorited: mail.favorited,
                    )));
      },
    );
  }
}

//Page for displaying drafts
class Drafts extends StatefulWidget {
  const Drafts({super.key, required String username});

  @override
  State<Drafts> createState() => _DraftsState();
}

class _DraftsState extends State<Drafts> {
  late String username;

  var db = DatabaseService();

  List<draft> _foundEntries = [];

  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      drawer: Drawer(
          child: ListView(
        children: [
          DrawerHeader(
              child: Column(
            children: [
              //TODO: Remove const when implement user profile picture
              const CircleAvatar(
                radius: 15,
                backgroundColor: Colors.yellow,
              ),
              Text(username)
            ],
          )),
          ListTile(
            leading: const Icon(Icons.star),
            title: const Text('Starred mail'),
            onTap: () {
              Navigator.pop(context);
              Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (ctx) => FavoritedMail(
                            username: username,
                          )));
            },
          ),
          ListTile(
            leading: const Icon(Icons.send),
            title: const Text('Sent mail'),
            onTap: () {
              Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (ctx) => SentMail(
                            username: username,
                          )));
            },
          ),
          ListTile(
              leading: const Icon(Icons.drafts),
              title: const Text('Drafts'),
              onTap: () {
                Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (ctx) => Drafts(username: username)));
              }),
          ListTile(
              leading: const Icon(Icons.delete_rounded),
              title: const Text('Trash'),
              onTap: () {
                Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (ctx) => Trash(username: username)));
              }),
          ListTile(
            leading: const Icon(Icons.block),
            title: const Text('Blocked list'),
            onTap: () {
              Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (ctx) => Blocklist(username: username)));
            },
          ),
          ListTile(
            leading: const Icon(Icons.settings),
            title: const Text('Settings'),
            onTap: () {
              Navigator.push(context,
                  MaterialPageRoute(builder: (ctx) => const Settings()));
            },
          )
        ],
      )),
      appBar: AppBar(
        title: const Text('Homepage'),
        backgroundColor: Colors.redAccent,
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            TextField(
              scrollPadding: const EdgeInsets.all(24),
              onChanged: (value) => _runFilter(value),
              decoration: const InputDecoration(
                  hintText: "Search", suffixIcon: Icon(Icons.search)),
            ),
            FutureBuilder(
              future: db.showDrafts(username),
              builder: (context, snapshot) {
                if (!snapshot.hasData) {
                  return const Center(
                    child: CircularProgressIndicator(),
                  );
                }
                List<draft> allMail = snapshot.data!;
                setState(() {
                  _foundEntries = allMail;
                });
                return _foundEntries.isEmpty
                    ? const Center(
                        child: Text('No mail'),
                      )
                    : ListView.separated(
                        itemBuilder: (ctx, idx) =>
                            _buildDrafts(_foundEntries[idx]),
                        separatorBuilder: (ctx, idx) => const Divider(),
                        itemCount: _foundEntries.length,
                      );
              },
            ),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () {
          Navigator.push(
              context, MaterialPageRoute(builder: (ctx) => const WriteMail()));
        },
        label: const Text('Write Email'),
        icon: const Icon(Icons.add),
      ),
    );
  }

  void _runFilter(String keyword) {
    List<draft> searchResults = [];
    if (keyword.isEmpty) {
      searchResults = _foundEntries;
    } else {
      searchResults = _foundEntries
          .where((draft) =>
              draft.title!.toLowerCase().contains(keyword.toLowerCase()))
          .toList();
      searchResults += _foundEntries
          .where((draft) =>
              draft.content!.toLowerCase().contains(keyword.toLowerCase()))
          .toList();
      searchResults += _foundEntries
          .where((draft) =>
              draft.sender!.toLowerCase().contains(keyword.toLowerCase()))
          .toList();
    }

    setState(() {
      _foundEntries = searchResults;
    });
  }

  Widget _buildDrafts(
    draft draft,
  ) {
    return ListTile(
      title: Text(draft.sender!),
      subtitle: Text(draft.title!),
      onTap: () {
        Navigator.push(
            context,
            MaterialPageRoute(
                builder: (ctx) => ReadMail(
                      mailID: draft.draftID,
                      sendTo: draft.sendTo!,
                      carbonCopy: draft.carbonCopy,
                      blindCopy: draft.blindCopy,
                      sender: draft.sender!,
                      title: draft.title!,
                      content: draft.content!,
                      chosenFile: draft.chosenFile!,
                      replyTo: draft.replyTo,
                      fowardTo: draft.forwardTo,
                      favorited: draft.favorited,
                    )));
      },
    );
  }
}

class Trash extends StatefulWidget {
  const Trash({super.key, required String username});

  @override
  State<Trash> createState() => _TrashState();
}

class _TrashState extends State<Trash> {
  late String username;

  var db = DatabaseService();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Trash'),
        backgroundColor: Colors.redAccent,
      ),
      body: const Text('Implement later'),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () {
          Navigator.push(
              context, MaterialPageRoute(builder: (ctx) => const WriteMail()));
        },
        label: const Text('Write Email'),
        icon: const Icon(Icons.add),
      ),
    );
  }
}

//Page that displays user blocklist
class Blocklist extends StatefulWidget {
  const Blocklist({super.key, required String username});

  @override
  State<Blocklist> createState() => _BlocklistState();
}

class _BlocklistState extends State<Blocklist> {
  late String username;

  var db = DatabaseService();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Blocklist'),
        backgroundColor: Colors.redAccent,
      ),
      body: FutureBuilder(
        future: db.showBlockList(username),
        builder: (context, snapshot) {
          if (!snapshot.hasData) {
            return const Center(
              child: CircularProgressIndicator(),
            );
          }
          List<Blocked> allBlocked = snapshot.data!;
          return allBlocked.isEmpty
              ? const Center(
                  child: Text('No blocked users'),
                )
              : ListView.separated(
                  itemBuilder: (ctx, idx) => _buildSenteMail(allBlocked[idx]),
                  separatorBuilder: (ctx, idx) => const Divider(),
                  itemCount: allBlocked.length,
                );
        },
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () {
          Navigator.push(
              context, MaterialPageRoute(builder: (ctx) => const WriteMail()));
        },
        label: const Text('Write Email'),
        icon: const Icon(Icons.add),
      ),
    );
  }

  Widget _buildSenteMail(
    Blocked blocked,
  ) {
    return ListTile(
      title: Row(
        children: [
          //TODO: Remove const when implement user profile picture
          const CircleAvatar(
            radius: 15,
            backgroundColor: Colors.yellow,
          ),
          Text(username), Text(blocked.blocked)
        ],
      ),
      trailing: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          PopupMenuButton(
              itemBuilder: (context) => [
                    PopupMenuItem(
                        child: ListTile(
                      leading: const Icon(Icons.cancel),
                      title: const Text('Remove from blocklist'),
                      onTap: () {
                        db.unblockUser(blocked.blocker, blocked.blocked);
                      },
                    ))
                  ])
        ],
      ),
    );
  }
}

//Page for settings
class Settings extends StatefulWidget {
  const Settings({super.key});

  @override
  State<Settings> createState() => _SettingsState();
}

class _SettingsState extends State<Settings> {
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    throw UnimplementedError();
  }
}

//Page for reading chosen eMails
class ReadMail extends StatefulWidget {
  const ReadMail({
    super.key,
    required int mailID,
    required String sendTo,
    required String? carbonCopy,
    required String? blindCopy,
    required String sender,
    required String title,
    required String content,
    required String chosenFile,
    required int? replyTo,
    required String? fowardTo,
    required int favorited,
  });

  @override
  State<ReadMail> createState() => _ReadMailState();
}

class _ReadMailState extends State<ReadMail> {
  var db = DatabaseService();

  late int mailID;
  late String sendTo;
  late String sender;
  late String? carbonCopy;
  late String? blindCopy;
  late String title;
  late String content;
  late String chosenFile;
  late int favorited;

  bool setFavorite(int fav) {
    if (fav == 0) {
      return false;
    }
    return true;
  }

  bool checkAttachments(String file) {
    if (file.isEmpty) {
      return false;
    }
    return true;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.redAccent,
        actions: [
          IconButton(
              onPressed: () async {
                if (favorited == 0) {
                  db.favoriteMail(mailID);
                  favorited = 1;
                  setState(() {});
                } else {
                  db.unFavoriteMail(mailID);
                  favorited = 0;
                }
              },
              icon: setFavorite(favorited)
                  ? const Icon(Icons.star_border)
                  : const Icon(Icons.star)),
          IconButton(
              onPressed: () {
                showDialog(
                    context: context,
                    builder: (ct) => AlertDialog(
                          title: const Text(
                              'Are you sure you want to delete this eMail?\n This option is IRRIVERSABLE!'),
                          actions: [
                            TextButton(
                                onPressed: () {
                                  Navigator.pop(context);
                                },
                                child: const Text("Cancel")),
                            TextButton(
                                onPressed: () {
                                  db.insertToTrash(
                                      mailID,
                                      sendTo,
                                      carbonCopy,
                                      blindCopy!,
                                      sender,
                                      title,
                                      content,
                                      chosenFile,
                                      null,
                                      null,
                                      favorited);
                                  Navigator.pop(context);
                                  Navigator.pop(context);
                                },
                                child: const Text("OK"))
                          ],
                        ));
              },
              icon: const Icon(Icons.delete)),
          IconButton(onPressed: () {}, icon: const Icon(Icons.more_horiz))
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            RichText(
              text: TextSpan(
                  style: const TextStyle(fontSize: 30),
                  children: <TextSpan>[
                    TextSpan(
                      text: '          $title',
                    )
                  ]),
            ),
            const SizedBox(
              height: 60,
            ),
            RichText(
              text: TextSpan(
                  style: const TextStyle(fontSize: 24),
                  children: <TextSpan>[
                    TextSpan(
                        text: sender.toString(),
                        style: const TextStyle(fontWeight: FontWeight.bold))
                  ]),
            ),
            const SizedBox(
              height: 40,
            ),
            RichText(
              text: TextSpan(
                  style: const TextStyle(fontSize: 24),
                  children: <TextSpan>[
                    TextSpan(
                        text: "cc: ${carbonCopy.toString()}",
                        style: const TextStyle(fontWeight: FontWeight.bold))
                  ]),
            ),
            const SizedBox(
              height: 40,
            ),
            RichText(
              text: TextSpan(
                  style: const TextStyle(fontSize: 18),
                  children: <TextSpan>[
                    TextSpan(
                      text: content,
                    )
                  ]),
            ),
            const Divider(),
            const SizedBox(
              height: 20,
            ),
            RichText(
              text: TextSpan(
                  style: const TextStyle(fontSize: 18),
                  children: <TextSpan>[
                    TextSpan(
                        text: checkAttachments(chosenFile)
                            ? 'Attachments: ${chosenFile.toString()}'
                            : null)
                  ]),
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                FloatingActionButton.extended(
                  onPressed: () {
                    Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (ctx) => ReplyMail(
                                  mailID: mailID,
                                  sendTo: sendTo,
                                  carbonCopy: carbonCopy,
                                  blindCopy: blindCopy,
                                  sender: sender,
                                  title: title,
                                  content: content,
                                )));
                  },
                  label: const Text(
                    'Reply',
                    style: TextStyle(fontSize: 20),
                  ),
                  icon: const Icon(Icons.reply),
                ),
                FloatingActionButton.extended(
                  onPressed: () {
                    Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (ctx) => FowardMail(
                                  mailID: mailID,
                                  sendTo: sendTo,
                                  sender: sender,
                                  title: title,
                                  content: content,
                                )));
                  },
                  label: const Text(
                    'Foward',
                    style: TextStyle(fontSize: 20),
                  ),
                  icon: const Icon(Icons.forward),
                ),
              ],
            )
          ],
        ),
      ),
    );
  }
}

//Page for replying
class ReplyMail extends StatefulWidget {
  const ReplyMail({
    super.key,
    required int mailID,
    required String sendTo,
    required String? carbonCopy,
    required String? blindCopy,
    required String sender,
    required String title,
    required String content,
  });

  @override
  State<ReplyMail> createState() => _ReplyMailState();
}

class _ReplyMailState extends State<ReplyMail> {
  final _key = GlobalKey<FormState>();
  var db = DatabaseService();

  late int mailID;
  late String sendTo;
  late String? carbonCopy;
  late String? blindCopy;
  late String sender;
  late String title;
  late String content;
  late String chosenFile;
  late int favorited;
  String? reply;
  String? replyFile;

  void _handleSubmission() {
    if (_key.currentState?.validate() ?? false) {
      _key.currentState?.save();
    } else {}
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Reply'),
        backgroundColor: Colors.redAccent,
        actions: [
          IconButton(
              onPressed: () async {
                _handleSubmission();
                title = "RE: $title";
                db.insertEMail(sender, sendTo, carbonCopy, blindCopy, title,
                    reply!, replyFile!, null, null);
                setState(() {});
                await showDialog(
                    context: context,
                    builder: (ct) => AlertDialog(
                          title: const Text('Reply sent succesfully'),
                          actions: [
                            TextButton(
                                onPressed: () {
                                  Navigator.pop(context);
                                  Navigator.pop(context);
                                  Navigator.pop(context);
                                },
                                child: const Text("ok"))
                          ],
                        ));
              },
              icon: const Icon(Icons.send))
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(24),
        child: Form(
          key: _key,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              RichText(
                text: TextSpan(
                    style: const TextStyle(fontSize: 30),
                    children: <TextSpan>[
                      TextSpan(
                        text: '          RE: $title',
                      )
                    ]),
              ),
              TextFormField(
                onChanged: (v) {
                  setState(() {
                    reply = v;
                  });
                },
                validator: (v) {
                  if (v == null || v.isEmpty) {
                    return "You must add a reply!";
                  }
                  return null;
                },
                maxLines: 5,
                keyboardType: TextInputType.text,
                decoration: const InputDecoration(
                  border: OutlineInputBorder(),
                ),
                onTap: () {},
              ),
              Row(
                children: [
                  ElevatedButton(
                      onPressed: () async {
                        final result = await FilePicker.platform.pickFiles();
                        if (result == null) {
                          return;
                        }
                        final file = result.files.first;
                        setState(() {
                          replyFile = file.name.toString();
                        });
                      },
                      child: const Text(
                        'Attach file',
                        style: TextStyle(fontSize: 20),
                      )),
                ],
              ),
              Row(
                children: [
                  Text("Attached file: ${replyFile ?? 'none'}"),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class FowardMail extends StatefulWidget {
  const FowardMail({
    super.key,
    required int mailID,
    required String sendTo,
    required String sender,
    required String title,
    required String content,
  });

  @override
  State<FowardMail> createState() => _FowardMailState();
}

class _FowardMailState extends State<FowardMail> {
  final _key = GlobalKey<FormState>();

  var db = DatabaseService();

  late int mailID;
  late String sendTo;
  late String sender;
  late String title;
  late String content;
  late String chosenFile;
  late int favorited;
  String? newSendTo;

  void _handleSubmission() {
    if (_key.currentState?.validate() ?? false) {
      _key.currentState?.save();
    } else {}
  }

  bool checkAttachments(String file) {
    if (file.isEmpty) {
      return false;
    }
    return true;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
          title: const Text('Foward'),
          backgroundColor: Colors.redAccent,
          actions: [
            IconButton(
                onPressed: () async {
                  _handleSubmission();
                  title = "RE: $title";
                  db.fowardToAnother(mailID, newSendTo!);
                  setState(() {});
                  await showDialog(
                      context: context,
                      builder: (ct) => AlertDialog(
                            title: const Text('Email forwarded succesfully'),
                            actions: [
                              TextButton(
                                  onPressed: () {
                                    Navigator.pop(context);
                                    Navigator.pop(context);
                                    Navigator.pop(context);
                                  },
                                  child: const Text("ok"))
                            ],
                          ));
                },
                icon: const Icon(Icons.send))
          ]),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(24),
        child: Form(
            child: Column(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                RichText(
                  text: const TextSpan(
                      style: TextStyle(fontSize: 30),
                      children: <TextSpan>[
                        TextSpan(
                          text: 'Foward to: ',
                        )
                      ]),
                ),
                TextFormField(
                  onChanged: (v) {
                    setState(() {
                      newSendTo = v;
                    });
                  },
                  validator: (v) {
                    if (v == null || v.isEmpty) {
                      return "Please enter foward email address.";
                    } else if (!v.contains("@") && !v.contains(".")) {
                      return "Invalid email address.";
                    }
                    return null;
                  },
                  maxLines: 1,
                  keyboardType: TextInputType.emailAddress,
                  decoration: const InputDecoration(
                    border: OutlineInputBorder(),
                  ),
                ),
              ],
            ),
            RichText(
              text: TextSpan(
                  style: const TextStyle(fontSize: 20),
                  children: <TextSpan>[
                    TextSpan(
                      text: '          $title',
                    )
                  ]),
            ),
            const SizedBox(
              height: 40,
            ),
            RichText(
              text: TextSpan(
                  style: const TextStyle(fontSize: 18),
                  children: <TextSpan>[
                    TextSpan(
                        text: sender.toString(),
                        style: const TextStyle(fontWeight: FontWeight.bold))
                  ]),
            ),
            const SizedBox(
              height: 30,
            ),
            RichText(
              text: TextSpan(
                  style: const TextStyle(fontSize: 12),
                  children: <TextSpan>[
                    TextSpan(
                      text: content,
                    )
                  ]),
            ),
            const Divider(),
            const SizedBox(
              height: 12,
            ),
            RichText(
              text: TextSpan(
                  style: const TextStyle(fontSize: 12),
                  children: <TextSpan>[
                    TextSpan(
                        text: checkAttachments(chosenFile)
                            ? 'Attachments: ${chosenFile.toString()}'
                            : null)
                  ]),
            ),
          ],
        )),
      ),
    );
  }
}

class WriteMail extends StatefulWidget {
  const WriteMail({super.key});
  @override
  State<WriteMail> createState() => _WriteMailstate();
}

//Page for writing new emails
class _WriteMailstate extends State<WriteMail> {
  final _key = GlobalKey<FormState>();

  var db = DatabaseService();

  void _handleSubmission() {
    if (_key.currentState?.validate() ?? false) {
      _key.currentState?.save();
    } else {}
  }

  String? sendTo;
  String? carbonCopy;
  String? blindCopy;
  String? sender;
  String? title;
  String? content;
  String? chosenfile;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        automaticallyImplyLeading: false,
        leading: IconButton(
            onPressed: () {
              showDialog(
                  context: context,
                  builder: (ct) => AlertDialog(
                          title: const Text('Email sent succesfully'),
                          actions: [
                            TextButton(
                                onPressed: () {
                                  db.insertDraft(
                                      sendTo,
                                      sender,
                                      carbonCopy,
                                      blindCopy,
                                      title,
                                      content,
                                      chosenfile,
                                      null,
                                      null);
                                },
                                child: const Text("Save")),
                            TextButton(
                                onPressed: () {
                                  Navigator.pop(context);
                                  sendTo = null;
                                  sender = null;
                                  title = null;
                                  content = null;
                                  chosenfile = null;
                                  Navigator.pop(context);
                                },
                                child: const Text("Don't save")),
                            TextButton(
                                onPressed: () {
                                  Navigator.pop(context);
                                },
                                child: const Text("Cancel"))
                          ]));
            },
            icon: const Icon(Icons.arrow_back_ios)),
        title: const Text('Send email'),
        backgroundColor: Colors.redAccent,
        actions: [
          IconButton(
              onPressed: () async {
                _handleSubmission();
                db.insertEMail(sendTo!, sender!, carbonCopy!, blindCopy!,
                    title!, content!, chosenfile!, null, null);
                setState(() {});
                await showDialog(
                    context: context,
                    builder: (ct) => AlertDialog(
                          title: const Text('Email sent succesfully'),
                          actions: [
                            TextButton(
                                onPressed: () {
                                  Navigator.pop(context);
                                  sendTo = null;
                                  sender = null;
                                  title = null;
                                  content = null;
                                  chosenfile = null;
                                  Navigator.pop(context);
                                },
                                child: const Text("ok"))
                          ],
                        ));
              },
              icon: const Icon(Icons.send))
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(24),
        child: Form(
          key: _key,
          child: Column(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                //Landing address of eMail
                Row(
                  children: [
                    const Text("Send to: "),
                    TextFormField(
                      onChanged: (v) {
                        setState(() {
                          sendTo = v;
                        });
                      },
                      validator: (v) {
                        if (v == null || v.isEmpty) {
                          return "Please enter reciever's email address.";
                        } else if (!v.contains("@") && !v.contains(".")) {
                          return "Invalid email address.";
                        }
                        return null;
                      },
                      maxLines: 1,
                      keyboardType: TextInputType.emailAddress,
                      decoration: const InputDecoration(
                        border: OutlineInputBorder(),
                      ),
                    ),
                  ],
                ),
                //Optional carbon copy
                Row(
                  children: [
                    const Text("CC: "),
                    TextFormField(
                      onChanged: (v) {
                        setState(() {
                          carbonCopy = v;
                        });
                      },
                      validator: (v) {
                        if (v == null || v.isEmpty) {
                          return null;
                        } else if (!v.contains("@") && !v.contains(".")) {
                          return "Invalid email address.";
                        }
                        return null;
                      },
                      maxLines: 1,
                      keyboardType: TextInputType.emailAddress,
                      decoration: const InputDecoration(
                        border: OutlineInputBorder(),
                      ),
                    ),
                  ],
                ),
                //Optional blind carbon copy
                Row(
                  children: [
                    const Text("Bcc: "),
                    TextFormField(
                      onChanged: (v) {
                        setState(() {
                          blindCopy = v;
                        });
                      },
                      validator: (v) {
                        if (v == null || v.isEmpty) {
                          return null;
                        } else if (!v.contains("@") && !v.contains(".")) {
                          return "Invalid email address.";
                        }
                        return null;
                      },
                      maxLines: 1,
                      keyboardType: TextInputType.emailAddress,
                      decoration: const InputDecoration(
                        border: OutlineInputBorder(),
                      ),
                    ),
                  ],
                ),

                //Sender of eMail
                Row(
                  children: [
                    const Text("Sender: "),
                    TextFormField(
                      onChanged: (v) {
                        setState(() {
                          sender = v;
                        });
                      },
                      validator: (v) {
                        if (v == null || v.isEmpty) {
                          return "Please enter your email address.";
                        } else if (!v.contains("@") && !v.contains(".")) {
                          return "Invalid email address.";
                        }
                        return null;
                      },
                      maxLines: 1,
                      keyboardType: TextInputType.emailAddress,
                      decoration: const InputDecoration(
                        border: OutlineInputBorder(),
                      ),
                      onTap: () {},
                    ),
                  ],
                ),
                //Title of eMail
                Row(
                  children: [
                    const Text("Title: "),
                    TextFormField(
                      onChanged: (v) {
                        setState(() {
                          title = v;
                        });
                      },
                      validator: (v) {
                        if (v == null || v.isEmpty) {
                          v = "No title";
                        }
                        return null;
                      },
                      maxLines: 1,
                      keyboardType: TextInputType.text,
                      decoration: const InputDecoration(
                        border: OutlineInputBorder(),
                      ),
                      onTap: () {},
                    ),
                  ],
                ),
                //Text content of eMail
                const Row(
                  children: [Text("Content: ")],
                ),
                TextFormField(
                  onChanged: (v) {
                    setState(() {
                      content = v;
                    });
                  },
                  validator: (v) {
                    if (v == null || v.isEmpty) {
                      v = " ";
                    }
                    return null;
                  },
                  maxLines: 5,
                  keyboardType: TextInputType.text,
                  decoration: const InputDecoration(
                    border: OutlineInputBorder(),
                  ),
                  onTap: () {},
                ),
                //Attach a file to your eMail.
                //Currently only inserts file name due to file being unsupported for sqflite.
                Row(
                  children: [
                    ElevatedButton(
                        onPressed: () async {
                          final result = await FilePicker.platform.pickFiles();
                          if (result == null) {
                            return;
                          }
                          final file = result.files.first;
                          setState(() {
                            chosenfile = file.name.toString();
                          });
                        },
                        child: const Text(
                          'Attach file',
                          style: TextStyle(fontSize: 20),
                        )),
                  ],
                ),
                Row(
                  children: [
                    Text("Attached file: ${chosenfile ?? 'none'}"),
                  ],
                ),
              ]),
        ),
      ),
    );
  }
}
