class Blocked {
  int blockID;
  String blocker;
  String blocked;

  Blocked(
    this.blockID,
    this.blocker,
    this.blocked,
  );

  Map<String, dynamic> toMap() {
    return {
      'blocker': blocker,
      'blocked': blocked,
    };
  }

  static Blocked fromMap(Map<String, dynamic> map) {
    return Blocked(map['blockID'], map['blocker'], map['blocked']);
  }
}
