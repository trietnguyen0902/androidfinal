import 'package:flutter_application_finals/blocked.dart';
import 'package:flutter_application_finals/email.dart';
import 'package:flutter_application_finals/user.dart';
import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';

class DatabaseService {
  static DatabaseService instance = DatabaseService._init();
  DatabaseService._init();

  factory DatabaseService() {
    return instance;
  }

  Database? _db;
  Future<Database> get database async {
    if (_db != null) {
      return _db!;
    }

    String appDB = 'app.db';
    String dbPath = join(await getDatabasesPath(), appDB);
    _db = await openDatabase(dbPath, version: 1, onCreate: (db, version) {
      db.execute('''CREATE TABLE USERS{
        userID INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT NOT NULL,
        userPassword TEXT NOT NULL,
      }

      CREATE TABLE EMAILS{
        mailID INTEGER PRIMARY KEY AUTOINCREMENT,
        sendTo TEXT NOT NULL,
        sender TEXT NOT NULL,
        title TEXT NOT NULL,
        content TEXT,
        chosenFile TEXT,
        replyTo INTEGER,
        forwardTo TEXT,
        favorited INTEGER,
      } 
      
      CREATE TABLE BLOCKLIST{
        blockID INTEGER PRIMARY KEY AUTOINCREMENT,
        blocker TEXT NOT NULL,
        blocked TEXT NOT NULL,
      }''');
    });

    return _db!;
  }

  Future<List<eMail>> showEmail(String user) async {
    var db = await database;
    var data =
        await db.rawQuery('SELECT * FROM EMAILS WHERE sendto = ?', [user]);
    return data.map((e) => eMail.fromMap(e)).toList();
  }

  Future<List<eMail>> showBlockList(String user) async {
    var db = await database;
    var data =
        await db.rawQuery('SELECT * FROM BLOCKLIST WHERE blocker = ?', [user]);
    return data.map((e) => eMail.fromMap(e)).toList();
  }

  Future<int> insertEMail(
    String sendTo,
    String sender,
    String title,
    String content,
    String chosenFile,
    int replyTo,
    int forwarded,
  ) async {
    var db = await database;
    return await db.insert(
        'EMAILS',
        eMail(0, sendTo, sender, title, content, chosenFile, replyTo, forwarded,
                0)
            .toMap());
  }

  Future<int> insertUser(String username, String userPassword) async {
    var db = await database;
    return await db.insert('USERS', User(0, username, userPassword).toMap());
  }

  Future<int> insertBlock(String blocker, String blocked) async {
    var db = await database;
    return await db.insert('BLOCKLIST', Blocked(0, blocker, blocked).toMap());
  }

  // Future<bool> deleteMail(eMail mail) async {
  //   var db = await database;
  //   return await db.delete('EMAILS', where: 'mailID = ?', whereArgs: [eMail.]);
  // }
}
