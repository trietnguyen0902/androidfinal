// ignore: camel_case_types
class eMail {
  int mailID;
  String sendTo;
  String sender;
  String title;
  String content;
  String chosenFile;
  int? replyTo;
  int? forwardTo;
  int favorited;

  eMail(this.mailID, this.sendTo, this.sender, this.title, this.content,
      this.chosenFile, this.replyTo, this.forwardTo, this.favorited);

  Map<String, dynamic> toMap() {
    return {
      'sendto': sendTo,
      'sender': sender,
      'title': title,
      'content': content,
      'chosenfile': chosenFile,
      'replyTo': replyTo,
      'forwarded': forwardTo,
      'favoriteTo': favorited
    };
  }

  static eMail fromMap(Map<String, dynamic> map) {
    return eMail(
        map['mailID'],
        map['sendTo'],
        map['sender'],
        map['title'],
        map['content'],
        map['chosenFile'],
        map['replyTo'],
        map['forwardTo'],
        map['favorited']);
  }
}
