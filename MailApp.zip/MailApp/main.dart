import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter_application_finals/database_service.dart';
import 'package:flutter_application_finals/email.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized;
  runApp(
      const MaterialApp(debugShowCheckedModeBanner: false, home: HomePage()));
}

//Homepage
class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  var db = DatabaseService();

  // Future<List<eMail>> loadData() async {
  //   await Future.delayed(const Duration(seconds: 1));
  //   var userEmails = [
  //     //eMail(this.mailID, this.sendTo, this.sender, this.title, this.content,
  //     //this.chosenFile, this.replyTo, this.forwardTo, this.favorited);
  //     eMail(1, 'adminNNT@mail.com', '123@mail.com', 'qwerty', 'wasd',
  //         'Readme.txt', null, null, 0),
  //     eMail(2, 'adminNNT@mail.com', '456@mail.com', 'asdfg', 'qwert',
  //         'Demo.txt', null, null, 0),
  //     eMail(3, 'adminNNT@mail.com', '123@mail.com', 'zxcvb', 'qazxsw',
  //         'Readme.txt', null, null, 0),
  //   ];
  //   return userEmails;
  // }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Homepage'),
        backgroundColor: Colors.redAccent,
      ),
      body: FutureBuilder(
        future: db.showEmail('adminNNT@mail.com'),
        builder: (context, snapshot) {
          if (!snapshot.hasData) {
            return const Center(
              child: CircularProgressIndicator(),
            );
          }
          List<eMail> allMail = snapshot.data!;
          return allMail.isEmpty
              ? const Center(
                  child: Text('No mail'),
                )
              : ListView.separated(
                  itemBuilder: (ctx, idx) => _buildMail(allMail[idx]),
                  separatorBuilder: (ctx, idx) => const Divider(),
                  itemCount: allMail.length,
                );
        },
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () {
          Navigator.push(
              context, MaterialPageRoute(builder: (ctx) => const WriteMail()));
        },
        label: const Text('Write Email'),
        icon: const Icon(Icons.add),
      ),
    );
  }

  Widget _buildMail(
    eMail mail,
  ) {
    return ListTile(
      title: Text(mail.sender),
      subtitle: Text(mail.title),
      onTap: () {},
    );
  }
}

class WriteMail extends StatefulWidget {
  const WriteMail({super.key});

  @override
  State<WriteMail> createState() => _WriteMailstate();
}

//eMail writing page
class _WriteMailstate extends State<WriteMail> {
  final _key = GlobalKey<FormState>();

  var db = DatabaseService();

  void _handleSubmission() {
    if (_key.currentState?.validate() ?? false) {
      _key.currentState?.save();
    } else {}
  }

  String? sendTo;
  String? sender;
  String? title;
  String? content;
  String? chosenfile;

  late SharedPreferences _prefs;

  void init() async {
    _prefs = await SharedPreferences.getInstance();
    setState(() {
      sender = _prefs.getString('sender') ?? '';
      sendTo = _prefs.getString('sendto') ?? '';
      title = _prefs.getString('title') ?? '';
      content = _prefs.getString('content') ?? '';
      chosenfile = _prefs.getString('attachment') ?? '';
    });
  }

  // @override
  // void initState() {
  //   var s1 = DatabaseService();
  //   var s2 = DatabaseService();
  //   super.initState();
  //   init();
  // }

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Send email'),
        backgroundColor: Colors.redAccent,
        actions: [
          IconButton(
              onPressed: () async {
                _handleSubmission();
                db.insertEMail(sendTo!, sender!, title!, content!, chosenfile!,
                    null, null);
                await showDialog(
                    context: context,
                    builder: (ct) => AlertDialog(
                          title: const Text('Email sent succesfully'),
                          actions: [
                            TextButton(
                                onPressed: () {
                                  Navigator.pop(context);
                                },
                                child: const Text("ok"))
                          ],
                        ));
              },
              icon: const Icon(Icons.send))
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(24),
        child: Form(
          key: _key,
          child: Column(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                //Landing address of eMail
                const Row(
                  children: [Text("Send to: ")],
                ),
                TextFormField(
                  onChanged: (v) {
                    setState(() {
                      sendTo = v;
                      _prefs.setString('sendto', v);
                    });
                  },
                  validator: (v) {
                    if (v == null || v.isEmpty) {
                      return "Please enter reciever's email address.";
                    } else if (!v.contains("@") && !v.contains(".")) {
                      return "Invalid email address.";
                    }
                    return null;
                  },
                  maxLines: 1,
                  keyboardType: TextInputType.emailAddress,
                  decoration: const InputDecoration(
                    border: OutlineInputBorder(),
                  ),
                ),
                //Sender of eMail
                const Row(
                  children: [Text("Sender: ")],
                ),
                TextFormField(
                  onChanged: (v) {
                    setState(() {
                      sender = v;
                      _prefs.setString('sender', v);
                    });
                  },
                  validator: (v) {
                    if (v == null || v.isEmpty) {
                      return "Please enter your email address.";
                    } else if (!v.contains("@") && !v.contains(".")) {
                      return "Invalid email address.";
                    }
                    return null;
                  },
                  maxLines: 1,
                  keyboardType: TextInputType.emailAddress,
                  decoration: const InputDecoration(
                    border: OutlineInputBorder(),
                  ),
                  onTap: () {},
                ),
                //Title of eMail
                const Row(
                  children: [Text("Title: ")],
                ),
                TextFormField(
                  onChanged: (v) {
                    setState(() {
                      title = v;
                      _prefs.setString('title', v);
                    });
                  },
                  validator: (v) {
                    if (v == null || v.isEmpty) {
                      v = "No title";
                    }
                    return null;
                  },
                  maxLines: 1,
                  keyboardType: TextInputType.text,
                  decoration: const InputDecoration(
                    border: OutlineInputBorder(),
                  ),
                  onTap: () {},
                ),
                //Text content of eMail
                const Row(
                  children: [Text("Content: ")],
                ),
                TextFormField(
                  onChanged: (v) {
                    setState(() {
                      content = v;
                      _prefs.setString('content', v);
                    });
                  },
                  validator: (v) {
                    if (v == null || v.isEmpty) {
                      v = " ";
                    }
                    return null;
                  },
                  maxLines: 5,
                  keyboardType: TextInputType.text,
                  decoration: const InputDecoration(
                    border: OutlineInputBorder(),
                  ),
                  onTap: () {},
                ),
                //Attach a file to your eMail.
                //Currently only inserts file name due to file being unsupported for sqflite.
                Row(
                  children: [
                    ElevatedButton(
                        onPressed: () async {
                          final result = await FilePicker.platform.pickFiles();
                          if (result == null) {
                            return;
                          }
                          final file = result.files.first;
                          setState(() {
                            chosenfile = file.name.toString();
                            _prefs.setString('attachment', chosenfile ?? '');
                          });
                        },
                        child: const Text(
                          'Attach file',
                          style: TextStyle(fontSize: 20),
                        )),
                  ],
                ),
                Row(
                  children: [
                    Text("Attached file: ${chosenfile ?? 'none'}"),
                  ],
                ),
              ]),
        ),
      ),
    );
  }
}
