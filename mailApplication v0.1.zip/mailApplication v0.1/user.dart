class User {
  int userID;
  String username;
  String userPassword;

  User(
    this.userID,
    this.username,
    this.userPassword,
  );

  Map<String, dynamic> toMap() {
    return {
      'username': username,
      'userPassword': userPassword,
    };
  }

  static User fromMap(Map<String, dynamic> map) {
    return User(map['userID'], map['username'], map['userPassword']);
  }
}
